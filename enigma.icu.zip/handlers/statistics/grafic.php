<?php
/*
 * Данные из файла для пстроения
 * графика на главной странице
 */
//$file = "./history/history.txt";
$file = "http://ru.tsignals.net/upload/history.txt";
$lines = file($file);
$lines = array_reverse($lines);
$count = count($lines);
for ($i = 0; $i<=18; $i++) {
    $fileNEW[$i] = $lines[$i];
}
$fileNEW = array_reverse($fileNEW);
// график за месяц
$day_month = 21; // число дней в месяце, для всех графиков
for ($i = 0; $i<=$day_month; $i++) {
    $fileNEW_1[$i] = $lines[$i];
}
$fileNEW_1 = array_reverse($fileNEW_1);
// график за полгода
$day_half_year = $day_month*6;
for ($i = 0; $i<=$day_half_year; $i++) {
    $fileNEW_2[$i] = $lines[$i];
}
$fileNEW_2 = array_reverse($fileNEW_2);
// график за год
$day_year = $day_month*12;
for ($i = 0; $i<=$day_year; $i++) {
    $fileNEW_3[$i] = $lines[$i];
}
$fileNEW_3 = array_reverse($fileNEW_3);

?>
<script type="text/javascript">
    var chartData_1 = [<?php foreach($fileNEW_1 as $key => $array){$explode = explode(";" , $array);$date = explode("." , $explode[0]);?>{"year": "<?=$date[0]?>.<?=$date[1]?>", "bicycles:''": <?=str_replace("\r\n", "", $explode[1])?>},<?php } ?>];
    var chartData_2 = [<?php foreach($fileNEW_2 as $key => $array){$explode = explode(";" , $array);$date = explode("." , $explode[0]);?>{"year": "<?=$date[0]?>.<?=$date[1]?>", "bicycles:''": <?=str_replace("\r\n", "", $explode[1])?>},<?php } ?>];
    var chartData_3 = [<?php foreach($fileNEW_3 as $key => $array){$explode = explode(";" , $array);$date = explode("." , $explode[0]);?>{"year": "<?=$date[0]?>.<?=$date[1]?>", "bicycles:''": <?=str_replace("\r\n", "", $explode[1])?>},<?php } ?>];
</script>