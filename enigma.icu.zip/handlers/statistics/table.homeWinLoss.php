<?php
$valute = Array(
    "EURUSD",
    "GBPUSD",
    "USDCHF",
    "USDCAD",
    "USDJPY",
    "XAGUSD", // Silver (Серебро)
    "EURCHF",
    "EURGBP",
    "AUDCAD",
    "AUDCHF",
    "CADCHF",
    "CHFJPY",
    "EURAUD",
    "EURCAD",
    "GBPAUD",
    "GBPCAD"
);
// Собираем массив для таблицы
// проверка на пустоту массива
if( count($valute) > 0 ){
    // проходим циклом по выводимым валютам
    foreach($valute as $val){
        // путь к файлам валют сигналов
        //$file = "./signal/".$val."_res.txt";
        $file = "http://ru.tsignals.net/upload/signal/".$val."_res.txt";
        $lines = array_reverse($lines);
        // выбираем строки
        $lines = file($file);
        // проходим по строкам файлов
        foreach($lines as $str){
            // разбиваем строки на массив
            $str_lines = explode(";", $str);
            // разбиваем дату и премя на массив
            $str_time = explode(" ", $str_lines[0]);
            // разбиваем время на массив
            $str_time_data = explode(":", $str_time[1]);
            // собираем выходной массив результатов
            //Tariy::Dump($str_lines, false, true);
            $table[] = Array(
                "SORT" => $str_time_data[0].$str_time_data[1].$str_time_data[2],
                "DATE_TIME" => $str_lines[0], // дата и время
                "TIME" => $str_time_data[0].":".$str_time_data[1], // нужное время
                "ACTIV" => $str_lines[1], // Актив
                "TYPE" => $str_lines[2], // Тип
                "PRICE_OPEN" => $str_lines[3], // Цена открытия
                "PRICE_EXIT" => $str_lines[4], // Цена закрытия
                "RESULT" => $str_lines[5], // Результат
                "P" => $str_lines[9], // Прибыль
            );
        }
    }
}
// Сортируем многомерный массив по полю "SORT" в обратном порядке
function mysort($a,$b) { return $a['SORT'] < $b['SORT'];}
usort($table, 'mysort' );

$win = "0";
$loss = "0";
$p = "0";
foreach($table as $key => $k){
    if($k["RESULT"]=="WIN"){
        $win = $win+1;
    }else
        if($k["RESULT"]=="LOSS"){
            $loss = $loss+1;
        }
    $p = $p+$k["P"];

}
$ks = $win+$loss;
?>
    <span class="total_item">Итого на данный час:</span>
    <span class="total_item">Количество сделок: <span class="red"><?=$ks?></span></span>
    <span class="total_item">Прибыль: <span class="red">$<?=$p?></span></span>