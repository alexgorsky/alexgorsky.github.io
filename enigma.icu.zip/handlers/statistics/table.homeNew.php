<?php
if( $_GET["key"]=="589-987-98r-re9" ){
$valute = Array(
    "EURUSD",
    "GBPUSD",
    "USDCHF",
    "USDCAD",
    "USDJPY",
    "XAGUSD", // Silver (Серебро)
    "EURCHF",
    "EURGBP",
    "AUDCAD",
    "AUDCHF", 
    "CADCHF",
    "CHFJPY",
    "EURAUD",
    "EURCAD",
    "GBPAUD",
    "GBPCAD"
);
// Собираем массив для таблицы
// проверка на пустоту массива
if( count($valute) > 0 ){
    // проходим циклом по выводимым валютам
    foreach($valute as $val){
        // путь к файлам валют сигналов
        //$file = "./signal/".$val."_res.txt";
        $file = "http://ru.tsignals.net/upload/signal/".$val."_res.txt";
        $lines = array_reverse($lines);
        // выбираем строки
        $lines = file($file);
        // проходим по строкам файлов
        foreach($lines as $str){
            // разбиваем строки на массив
            $str_lines = explode(";", $str);
            // разбиваем дату и премя на массив
            $str_time = explode(" ", $str_lines[0]);
            // разбиваем время на массив
            $str_time_data = explode(":", $str_time[1]);
            $time_1 = $str_lines[8];
            $time_2 = $str_time_data[0].":".$str_time_data[1];
            // собираем выходной массив результатов
            $table[] = Array(
                "SORT" => $str_time_data[0].$str_time_data[1].$str_time_data[2],
                "DATE_TIME" => $str_lines[0], // дата и время
                "TIME" => $time_2, // нужное время
                "ACTIV" => $str_lines[1], // Актив
                "TYPE" => $str_lines[2], // Тип
                "PRICE_OPEN" => $str_lines[3], // Цена открытия
                "PRICE_EXIT" => $str_lines[4], // Цена закрытия
                "RESULT" => $str_lines[5], // Результат
                "P" => $str_lines[9], // Прибыль
                "S" => $str_lines[7], // Ставка
                "T" => $time_1, // Время входа
            );
        }
    }
}
// Сортируем многомерный массив по полю "SORT" в обратном порядке
function mysort($a,$b) { return $a['SORT'] < $b['SORT'];}
usort($table, 'mysort' );
?>
    <ul>
        <?foreach($table as $key => $td){?>
        <li>
            <span class="li_1"><?=$td["ACTIV"]?></span>
            <span class="li_2"><span class="<?php if($td["TYPE"]=="call"){?>call<?php }else{?>put<?php }?>"><?php if($td["TYPE"]=="call"){?>&#10144;<?php }else{?>&#10144;<?php }?></span><span><?=$td["TYPE"]?></span></span></span>
            <span class="li_3"><?=$td["T"]?></span>
            <span class="li_4"><?=$td["PRICE_OPEN"]?></span>
            <span class="li_5"><?=$td["TIME"]?></span>
            <span class="li_5"><?=$td["PRICE_EXIT"]?></span>
            <span class="li_7">$<?=round($td["S"])?></span>
            <span class="li_8<?php if($td["RESULT"]=="WIN"){?> ok<?php }else{?> no<?php }?>"><?php if( $td["P"]>0 ){?>+$<?=round($td["P"], 2)?><?php }else{?>$0<?php }?></span>
        </li>
        <?}?>
    </ul>
<?php }?>