(function (r) {
  "use strict";
  var gulp = r('gulp'),
    compass = r('gulp-compass'),
    autoprefixer = r('gulp-autoprefixer'),
    cssnano = r('gulp-cssnano'),
    rename = r('gulp-rename'),
    concat = r('gulp-concat'),
    uglify = r('gulp-uglify'),
    uncomment = r('gulp-uncomment'),
    size = r('gulp-size'),
    notify = r('gulp-notify'),
    mainBowerFiles = r('main-bower-files');

  //compass
  gulp.task('compass', function() {
    return gulp.src(['./sass/*.scss', './sass/**/*.scss'])
      .pipe(compass({
        config_file: './config.rb',
        css: '../css',
        sass: './sass'
      }))
      .pipe(gulp.dest('../css'));
  });

  //style.min.css
  gulp.task('style', ['compass'], function() {
    return gulp.src(['./js/vendor/normalize.css/normalize.css', '../css/screen.css'])
      .pipe(concat('style.min.css'))
      .pipe(cssnano({autoprefixer: {browsers: ['last 30 versions','> 5%'], add: true}}))
      .pipe(size({title: 'size of style.min.css'}))
      .pipe(gulp.dest('../css'))
      .pipe(notify("style.min.css complete"));
  });

  //main.min.js
  gulp.task('scriptsMain', function() {
    return gulp.src('./js/*.js')
      .pipe(uncomment({removeEmptyLines: true}))
      .pipe(concat('main.min.js'))
      .pipe(uglify())
      .pipe(size({title: 'size of main.min.js'}))
      .pipe(gulp.dest('../js'))
      .pipe(notify("main.min.js complete"));
  });

  //bower
  gulp.task('bowerJS', function() {
    return gulp.src(mainBowerFiles('**/*.js'))
      .pipe(gulp.dest('../js/libs'));
  });
  gulp.task('bowerCss', function() {
    return gulp.src(mainBowerFiles(['**/*.css', '**/*.png', '**/*.gif', '**/*.jpg']))
      .pipe(gulp.dest('../js/libs/css'));
  });

  //libs.min.css
  gulp.task('libsCss', ['bowerCss'], function() {
    return gulp.src(['!../js/libs/css/libs.min.css', '../js/libs/css/*.css'])
      .pipe(concat('libs.min.css'))
      .pipe(cssnano({autoprefixer: {browsers: ['last 30 versions','> 5%'], add: true}}))
      .pipe(size({title: 'size of libs.min.css'}))
      .pipe(gulp.dest('../js/libs/css'))
      .pipe(notify("libs.min.css complete"));
  });

  //watch
  gulp.task('watch', function() {
    gulp.watch(['./sass/*.scss', './sass/**/*.scss'], ['compass', 'style']);
    gulp.watch(['../js/libs/css/*.css'], ['libsCss']);
    gulp.watch('./js/*.js', ['scriptsMain']);
  });

  //default
  gulp.task('default', ['compass', 'style', 'scriptsMain', 'bowerJS',  'bowerCss', 'libsCss', 'watch']);
}(require));